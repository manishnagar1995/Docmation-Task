declare module "@salesforce/apex/Docmation.getContacts" {
  export default function getContacts(): Promise<any>;
}
declare module "@salesforce/apex/Docmation.saveContact" {
  export default function saveContact(param: {conList: any, varboolean: any}): Promise<any>;
}
